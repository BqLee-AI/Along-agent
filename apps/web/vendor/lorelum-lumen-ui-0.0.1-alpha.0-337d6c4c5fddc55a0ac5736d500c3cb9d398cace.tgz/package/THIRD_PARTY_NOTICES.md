# 第三方声明

本目录的组件通过官方 shadcn CLI 从 @shadcn registry 引入，基于 Base UI；Chart 组件组合 Recharts。以下许可适用于相关上游代码，不代表 LumenUI 自有代码已采用同一许可。

## shadcn/ui — MIT

MIT License

Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Streamdown — Apache-2.0

Markdown 使用 Streamdown 作为外部运行依赖，遵循其 Apache-2.0 许可。许可证随 streamdown 包分发。

## Shiki — MIT

CodeBlock 使用 Shiki 作为外部运行依赖，遵循其 MIT 许可。许可证随 shiki 包分发。

## Yet Another React Lightbox — MIT

Image.Preview 使用 Yet Another React Lightbox 及其 Zoom 插件作为外部运行依赖，遵循其 MIT 许可。许可证随 yet-another-react-lightbox 包分发，版权所有者为 Igor Danchenko。
