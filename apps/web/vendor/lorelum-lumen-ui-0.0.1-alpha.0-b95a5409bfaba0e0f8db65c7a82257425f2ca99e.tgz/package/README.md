# LumenUI

基于 shadcn/ui、Base UI 与 Tailwind v4 的 React 组件库。提供操作、表单、表格、卡片、弹层与图表组件；组件不包含业务请求、路由和权限逻辑。

## 安装与样式

下面以本地生成的非 scoped 包为例：

```sh
bun add ./lumen-ui-0.0.1-alpha.0.tgz react@19 react-dom@19
bun add -d tailwindcss@4 @tailwindcss/vite@4
```

在 Vite plugins 中启用 `@tailwindcss/vite`，在应用 CSS 引入：

```css
@import "tailwindcss";
@import "lumen-ui/theme.css";
@source "../node_modules/lumen-ui/dist";
```

```tsx
import { Button } from "lumen-ui/components/button";
import { Card, CardHeader, CardTitle, CardContent } from "lumen-ui/components/card";
import { themePresets, type ThemePreset } from "lumen-ui/themes";

<section className="lumen-ui bg-background text-foreground" data-preset="linen">
  <Card>
    <CardHeader>
      <CardTitle>项目</CardTitle>
    </CardHeader>
    <CardContent>
      <Button onClick={onCreate}>新建项目</Button>
    </CardContent>
  </Card>
</section>;
```

组件可按路径导入，也可从包根导入。`themes` 提供预设元数据与默认值。`theme.css` 已包含 Linen 和动画规则，不需要安装 `@lorelum/lumen-ui-theme`。

使用 scoped 包时，安装名、导入路径与 `@source` 路径统一换成 `@lorelum/lumen-ui`。两个包从同一源码生成，React / React DOM 是外部 peer dependency。

## 主题、材质与弹层

只提供 `Linen`（`linen`）一个设计预设；材质只定义表面的透光、雾化和层次，不会增加主题。应用 CSS 的 scoped 入口是 `@lorelum/lumen-ui/theme.css`，普通应用无需安装独立的 `@lorelum/lumen-ui-theme` 包。

`LumenProvider` 从 `@lorelum/lumen-ui/themes` 或包根导出。其可选的 `theme?: ThemeDefinition` 和 `mode?: "light" | "dark"` props 与标准 `div` props 兼容。Provider 创建 `.lumen-ui` 主题根和 portal 容器；嵌套 provider 继承外层主题与模式，也可局部覆盖。`useLumenTheme()` 返回最近 provider 的有效 `theme` 和 `mode`。模式状态和持久化由应用管理，provider 不读取 `localStorage`。

```tsx
import { defineTheme, LumenProvider } from "@lorelum/lumen-ui/themes";

const theme = defineTheme({
  materials: {
    player: { extends: "smoked", blur: 12, dark: { tint: "#141e19" } },
  },
  variables: {
    light: { "--brand": "#007AFF" },
    dark: { "--brand": "#007AFF" },
  },
});

<LumenProvider mode="dark" theme={theme}>
  <Application />
</LumenProvider>;
```

`defineTheme`、`LumenProvider`、`useLumenTheme` 与 `useMaterial` 可从 `@lorelum/lumen-ui/themes` 或 UI 包根导入。主题包自身也提供 `@lorelum/lumen-ui-theme/react`，但完整应用应统一使用 UI 包导出的 React 绑定，避免混用两套 React context。

`Button` 的外观与颜色分别设置：`variant` 为 `solid`、`glass`、`clear`、`flat`，`color` 支持 `default`、`primary`、`danger` 以及自定义 CSS 颜色（如 `#8b5cf6`、`oklch(...)`、`var(--brand)`）。默认使用 `solid` + `primary`；`flat` 为淡色填充，没有边缘反光或背景模糊，保留所有 Button 共用的轻阴影。通过 `defineTheme({ materials: { tinted: { tint: "#007AFF" } } })` 定制主色材质。`Button` 与 `Card` 接受 `material`，显式设置后完整替换默认表面：

```tsx
<Button material="clear">轻量操作</Button>
<Card material={{ preset: "panel", blur: 12 }}>浮层内容</Card>
```

自定义组件可调用 `useMaterial(input)`。它返回 `className`、`style` 和 `data-material`，直接展开到组件自己的 DOM，并与已有 `className`、`style` 合并；不需要额外的材质包装组件。材质参数包括接受任意 CSS 颜色（含变量）的 `tint`、0–100 的 `transmission`、`highlight`、`shadow`，px 单位的 `blur`、`edgeSoftness`，以及可选的任意 CSS 颜色 `foreground`。圆角由具体组件控制。

自定义材质名通过模块扩展登记：

```ts
declare module "@lorelum/lumen-ui/themes" {
  interface MaterialRegistry {
    player: true;
  }
}
```

`DialogContent`、`Select.Content` 和 `Dropdown.Content` 默认使用最近的 `LumenProvider` portal 容器；显式传入 `portalContainer` 时优先使用该值。它们继承同一主题变量与模式，支持 `material` 替换表面。标准 Base UI 的 `render`、受控状态与原生语义继续可用。

Card 提供 `default`（白色边界与轻阴影）、`soft`（浅灰底）、`plain`（无外框）三种呈现，用来表达内容层次。Button、Input、Select 与 Badge 使用胶囊形，Dialog 使用更宽松的间距与柔和阴影。优先使用这些 variant，不在消费页覆写组件外观。

`Chart` 默认不绘制背景、模糊、边缘反光或阴影，可直接嵌入 Card，不需要 `variant`。按需通过 `material` 添加独立材质表面；`Chart.Tooltip` 的浮层材质独立保留。系列的 `config.icon` 同时用于图例与提示，可表达实线、虚线等标记；坐标文字和参考线沿用所在主题或材质的语义色。

主题字体栈优先 Inter Variable / Inter，中文使用系统字体。字体文件由消费应用选择提供；example 通过 `@fontsource-variable/inter/wght.css` 自托管。

## 维护

公开源码按组件组织在 `src/components/`；theme 是颜色、圆角与阴影的唯一来源。新增组件通过官方 shadcn CLI，不另写重复基础控件。example 展示真实交互，但其中的演示数据与项目模型不属于组件 API。

上游源码许可见 `THIRD_PARTY_NOTICES.md`。LumenUI 自有代码标记 UNLICENSED，公开使用许可另行确定。
