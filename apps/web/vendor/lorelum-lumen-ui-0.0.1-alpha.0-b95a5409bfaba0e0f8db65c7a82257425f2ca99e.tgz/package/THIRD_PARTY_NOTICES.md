# 第三方声明

本目录的组件通过官方 shadcn CLI 从 @shadcn registry 引入，基于 Base UI；Chart 组件组合 Recharts。以下许可适用于相关上游代码，不代表 LumenUI 自有代码已采用同一许可。

## shadcn/ui — MIT

MIT License

Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Streamdown — Apache-2.0

Markdown 使用 Streamdown 作为外部运行依赖，遵循其 Apache-2.0 许可。许可证随 streamdown 包分发。

## Shiki — MIT

CodeBlock 使用 Shiki 作为外部运行依赖，遵循其 MIT 许可。许可证随 shiki 包分发。

## Yet Another React Lightbox — MIT

Image.Preview 使用 Yet Another React Lightbox 及其 Zoom 插件作为外部运行依赖，遵循其 MIT 许可。许可证随 yet-another-react-lightbox 包分发，版权所有者为 Igor Danchenko。

## React Aria / React Stately — Apache-2.0

ColorPicker 使用 Adobe 的 @react-aria/color 与 @react-stately/color 作为外部运行依赖，处理颜色解析、色彩通道、二维选择与无障碍交互。控件的共享焦点机制使用 react-aria 的 useFocusRing 跟踪真实焦点和交互方式。许可证随对应包分发。

## React DayPicker — MIT

Calendar 使用 @daypicker/react 作为外部运行依赖，处理日期计算、选择与键盘导航。许可证随该包分发。

## cmdk — MIT

Command 使用 cmdk 1.1.1 作为外部运行依赖，处理搜索过滤、列表键盘导航与选中动作。Copyright (c) 2022 Paco Coursey，许可证随 cmdk 包分发。

## date-fns — MIT

DatePicker 使用 date-fns 4.4.0 作为外部运行依赖，处理日期格式化与解析。Copyright (c) 2021 Sasha Koss and Lesha Koss，许可证随 date-fns 包分发。

## use-stick-to-bottom — MIT

Conversation 使用 use-stick-to-bottom 1.1.6 作为外部运行依赖，处理跟随底部、内容尺寸变化与用户滚动取消跟随。Copyright (c) 2024 - present StackBlitz，许可证随该包分发。
